package cwk4;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static cwk4.BattleType.AMBUSH;

/**
 * This class implements the behaviour expected from a WIN
 system as required for 5COM2007 - March 2023
 *
 * @author Team ??
 * @version March 2023
 */

public class SpaceWars implements WIN
{

//**************** WIN **************************
    /** Constructor requires the name of the admiral
     *  the name of the admiral
     */
    private String admiralName;
    private int warChest;

    private List<Force> activeStarFleet;
    private List<Force> uffDock;
    private List<Force> destroyedForces;
    ArrayList<Battle> battleList = new ArrayList<>();
    ArrayList<Integer> battleKeys;
    public SpaceWars(String admiral)
    {

        this.admiralName=admiral;
        this.warChest = 1000;
        this.activeStarFleet = new ArrayList<>();
        this.uffDock = new ArrayList<>();
        this.destroyedForces = new ArrayList<>();

        this.battleKeys = new ArrayList<>();

        setupForces();
        setupBattles();

    }
    public SpaceWars(String admiral, String fname) {

        this.battleKeys = new ArrayList<>();
        this.admiralName = admiral;
        restoreGame(fname);
        setupForces();



    }

    public int getWarChest() {
        return this.warChest;
    }

    /**Returns a String representation of the state of the game,
     * including the name of the admiral, state of the war chest,
     * whether defeated or not, and the forces currently in the
     * Active Star Fleet(ASF),(or, "No forces" if Star Fleet is empty)
     * @return a String representation of the state of the game,
     * including the name of the admiral, state of the war chest,
     * whether defeated or not, and the forces currently in the
     * Star Fleet,(or, "No forces" if Active Star Fleet is empty)
     **/
    public String toString()
    {

        return "\nAdmiral Name"+this.admiralName+
                "\nWar Chest State:"+getWarchest()+
                "\nIs Defeated? "+isDefeated()+
                "\nThe Forces Currently in The Active Star Fleet(ASF)\n"+getAllForces();
    }


    /** returns true if war chest <=0 AND the active Star Fleet(ASF) has no
     * forces which can be recalled.
     * @returns true if war chest <=0 and the active Star Fleet(ASF) has no
     * forces which can be recalled.
     */
    public boolean isDefeated()
    {
        if(getWarChest()<=0 && activeStarFleet.isEmpty()) {
            return true;
        }
        else {
            return false;
        }
    }


    /** returns the number of bit coins in the war chest
     * @returns the number of bit coins in the war chest
     */
    public int getWarchest()
    {
        return this.warChest;
    }

    /* Returns a list of all forces in the system by listing :
     * All forces in the Active Star Fleet(ASF), or "No forces in ASF")
     * All forces remaining in the UFF dock, or "No forces in UFF dock
     * All forces destroyed as a result of losing a battle, or "No destroyed forces"
     */
    public String getAllForces()
    {

        StringBuilder sb = new StringBuilder();
        // Check if there are any active forces in the Star Fleet
        if (activeStarFleet.isEmpty()) {
            sb.append("No forces in ASF\n");
        } else {
            sb.append("Active Star Fleet:\n");
            for (Force force : activeStarFleet) {
                sb.append("- ").append(force.toString()).append("\n\n");
            }
        }
        // Check if there are any forces in the UFF dock
        if (uffDock.isEmpty()) {
            sb.append("No forces in UFF dock\n");
        } else {
            sb.append("UFF Dock:\n");
            for (Force force : uffDock) {
                sb.append("- ").append(force.toString()).append("\n\n");
            }
        }

        if (destroyedForces.isEmpty()) {
            sb.append("No forces in destroyed Forces \n");
        } else {
            sb.append("Destroyed Forces:\n");
            for (Force force : destroyedForces) {
                sb.append("- ").append(force.toString()).append("\n\n");
            }
        }

        return sb.toString();
    }


    /**Returns true if force is in the United Forces Fleet(UFF), else false
     * @param ref reference of the force
     * @return a String representation of all forces in the United Forces Fleet(UFF)
     **/
    public boolean isInUFFDock(String ref) {
        for (Force force : uffDock) {
            if (force.getReferenceNumber().equals(ref)) {
                return true;
            }
        }
        return false;
    }


    /**Returns a String representation of all forces in the United Forces Fleet(UFF) dock.
     * Does not include destroyed forces
     * @return a String representation of all forces in the United Forces Fleet(UFF) dock.
     **/
    public String getForcesInDock() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n\n************ Forces available in UFFleet Dock********\n");
        for (Force force : uffDock) {
            if (!destroyedForces.contains(force)) {
                sb.append(force.toString()).append("\n");
            }
        }
        return sb.toString();
    }
    /** Returns a list of all destroyed forces in the system
     * @return all destroyed forces
     */
    public String getDestroyedForces() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n***** Destroyed Forces ****\n");
        for (Force force : destroyedForces) {
            sb.append(force.toString()).append("\n");
        }
        return sb.toString();
    }


    /** Returns details of the force with the given reference code, or "No such force"
     * @param ref the reference of the force
     * @return details of the force with the given reference code
     **/
    public String getForceDetails(String ref) {
        // Check if force is in activeStarFleet
        for (Force force : activeStarFleet) {
            if (force.getReferenceNumber().equals(ref)) {
                return force.toString();
            }
        }
        // Check if force is in uffDock
        for (Force force : uffDock) {
            if (force.getReferenceNumber().equals(ref)) {
                return force.toString();
            }
        }
        // Check if force has been destroyed
        for (Force force : destroyedForces) {
            if (force.getReferenceNumber().equals(ref)) {
                return force.toString();
            }
        }
        // Force not found
        return "\nNo such force";
    }

    // ***************** Active Star Fleet Forces ************************
    /** Allows a force to be activated into the Active Star Fleet(ASF), but
     * only if there are enough resources for the activation fee.The force's
     * state is set to "active"
     * @param ref represents the reference code of the force
     * @return 0 if force is activated, 1 if force is not in the UFF dock or is destroyed
     * 2 if not enough money, -1 if no such force
     **/
    public int activateForce(String ref)
    {
        // Check if the force exists
        Force force = null;
        for (Force f : uffDock) {
            if (f.getReferenceNumber().equals(ref)) {
                force = f;
                break;
            }
        }
        if (force == null) {
            return -1; // No such force
        }

        // Check if the force is already active
        else if (activeStarFleet.contains(force)) {
            return 0; // Force is already active
        }

        // Check if the force is destroyed
        else if (destroyedForces.contains(force)) {
            return 1; // Force is destroyed
        }

        // Check if there are enough resources for the activation fee
        else if (warChest >= force.getActivationFee()) {
            // Deduct the activation fee from the war chest
            warChest -= force.getActivationFee();
            force.setForceState("active");

            // Activate the force
            uffDock.remove(force);
            activeStarFleet.add(force);

            // Return success
            return 0;

        }
        else {
            // Not enough resources for activation fee
            return 2;
        }
    }


    /** Returns true if the force with the reference code is in
     * the Active Star Fleet(ASF), false otherwise.
     * @param ref is the reference code of the force
     * @return returns true if the force with the reference code
     * is in the active Star Fleet(ASF), false otherwise.
     **/
    public boolean isInASFleet(String ref)
    {
        for (Force force : activeStarFleet) {
            if (force.getReferenceNumber().equals(ref)) {
                return true;
            }
        }
        return false;
    }

    /**Returns a String representation of the forces in the active
     * Star Fleet(ASF), or the message "No forces activated"
     * @return a String representation of the forces in the active
     * Star Fleet, or the message "No forces activated"
     **/
    public String getASFleet() {
        String s = "\n****** Forces in the Active Star Fleet******\n";
        if (activeStarFleet.isEmpty()) {
            s += "No forces activated";
        } else {
            for (Force force : activeStarFleet) {
                s += force.toString() + "\n";
            }
        }
        return s;
    }

    /** Recalls a force from the Star Fleet(ASF) back to the UFF dock, but only
     * if it is in the Active Star Fleet(ASF)
     * @param ref is the reference code of the force
     **/
    public void recallForce(String ref) {
        for (Force force : activeStarFleet) {
            if (force.getReferenceNumber().equals(ref) && !destroyedForces.contains(force)) {
                activeStarFleet.remove(force);
                uffDock.add(force);
                force.setForceState(ForceState.DOCKED);
                this.warChest=this.warChest+(force.getActivationFee())/2;
                return;
            }

        }
    }

//**********************Battles*************************
    /**
     * returns true if the number represents a battle
     *
     * @param num is the number of the required battle
     * @returns true if the number represents a battle
     **/

    public boolean isBattle(int num)
    {
        for(Battle battle:battleList)
        {


            return true;
        }
        return false;
    }


    /** Provides a String representation of a battle given by
     * the battle number
     * @param num the number of the battle
     * @return returns a String representation of a battle given by
     * the battle number
     **/
    public String getBattle(int num) {
        for (Battle battle : battleList) {
            if (battle.getNumber() == num) {
                return battle.toString();
            }
        }
        return "No such battle";
    }


    /** Provides a String representation of all battles
     * @return returns a String representation of all battles
     **/
    public String getAllBattles() {
        String s = "\n************ All Battles ************\n";
        if (battleList.isEmpty()) {
            s += "No battles recorded";
        } else {
            for (Battle battle : battleList) {
                s += battle.toString() + "\n";
            }
        }
        return s;
    }


    /** Retrieves the battle represented by the battle number.Finds
     * a force from the Active Star Fleet which can engage in the battle.The
     * results of battle will be one of the following:
     * 0 - Battle won, battle gains added to the war chest,
     * 1 - Battle lost as no suitable force available, battle losses
     * deducted from war chest
     * 2 - Battle lost on battle strength , battle losses
     * deducted from war chest and force destroyed
     * 3 - If a battle is lost and admiral completely defeated (no resources and
     * no forces to recall)
     * -1 - no such battle
     * @param battleNo is the number of the battle
     * @return an int showing the result of the battle (see above)
     */
    public int doBattle(int battleNo)
    {
        Battle battle=null;
        for(Battle bat:battleList)
        {
            if(bat.getNumber()==battleNo)
            {
                battle=bat;
                break;
            }
        }


if(battle!=null)
{
   for(Force force:activeStarFleet)
   {
       if (force instanceof Wings && (battle.getType()==BattleType.SKIRMISH ||battle.getType()==BattleType.AMBUSH))
       {
        if(force.getBattleStrength()>=battle.getEnemyStrength())
        {
            this.warChest+=battle.getGains();
            return 0;
        }
        else
        {
            this.warChest-=battle.getLosses();
            activeStarFleet.remove(force);
            destroyedForces.add(force);
            return 2;
        }
       }
       else if (force instanceof StarShips && (battle.getType()==BattleType.SKIRMISH ||battle.getType()==BattleType.FIGHT))
       {
           if(force.getBattleStrength()>=battle.getEnemyStrength())
           {
               this.warChest+=battle.getGains();
               return 0;
           }
           else
           {
               this.warChest-=battle.getLosses();
               activeStarFleet.remove(force);
               destroyedForces.add(force);
               return 2;
           }
       }
       else if(force instanceof WarBirds && (battle.getType()==BattleType.FIGHT || (battle.getType()==BattleType.AMBUSH && force.hasCloakingDevice())))
       {

           if(force.getBattleStrength()>=battle.getEnemyStrength())
           {
               this.warChest+=battle.getGains();

               return 0;
           }
           else
           {

               this.warChest-=battle.getLosses();
               activeStarFleet.remove(force);
               destroyedForces.add(force);
               return 2;
           }
       }



   }
    this.warChest-=battle.getLosses();

    return 1;
}
else
{
    return -1;
}
    }

    //*******************************************************************************
    private void setupForces()
    {
        Force force1 = new Wings("IW1", "Twister", "Docked",10);
        uffDock.add(force1);
        Force force2 = new StarShips("SS2", "Enterprise", "docked", 10, 20);
        uffDock.add(force2);
        Force force3 = new WarBirds("WB3", "Droop", 100,"docked", false);
        uffDock.add(force3);
        Force force4 = new Wings("IW4", "Winger","docked", 20);
        uffDock.add(force4);


        Force force5 = new WarBirds("WB5", "Hang",300,"docked", true);
        uffDock.add(force5);

        Force force6 = new StarShips("SS6", "Voyager","docked", 15, 10);
        uffDock.add(force6);


        Force force7 = new StarShips("SS7", "Explorer","docked", 4, 5);
        uffDock.add(force7);

        Force force8 = new WarBirds("WB9", "Hover", 400,"docked", false);
        uffDock.add(force8);



        Force force9 = new Wings("IW10", "Flyer", "docked", 5);
        uffDock.add(force9);
    }

    private void setupBattles()
    {
        Battle battle1 = new Battle(BattleType.FIGHT, "Borg", 200, 300, 100);
        battleList.add(battle1);
        Battle battle2 = new Battle(BattleType.SKIRMISH, "Kardassians", 700, 200, 120);
        battleList.add(battle2);
        Battle battle3 = new Battle(AMBUSH, "Ferengi", 100, 400, 150);
        battleList.add(battle3);
        Battle battle4 = new Battle(BattleType.FIGHT, "Ewoks", 600, 600, 200);
        battleList.add(battle4);
        Battle battle5 = new Battle(AMBUSH, "Borg", 500, 400, 90);
        battleList.add(battle5);
        Battle battle6 = new Battle(BattleType.SKIRMISH, "Groaners", 150, 100, 100);
        battleList.add(battle6);
        Battle battle7 = new Battle(BattleType.FIGHT, "Borg", 150, 500, 300);
        battleList.add(battle7);
        Battle battle8 = new Battle(AMBUSH, "Wailers", 300, 300, 300);
        battleList.add(battle8);


    }

    //**************************Add your own private methos here ***********************

    private Battle Battle(int battleNo)
    {
        Battle battle=null;
        for(Battle bat:battleList)
        {
            if (bat.getNumber()==battleNo)
            {
                 battle=bat;
            }

        }
        return battle;
    }

    //*******************************************************************************

    //These methods are not needed until Task 3.5. Uncomment thmemto complete task 3.5
    // ***************   file write/read  *********************

     /** Writes whole game to the specified file
     * @param fname name of file storing requests
      * */
   public void saveGame(String fname)
    {       try {
        FileOutputStream fileOut = new FileOutputStream(fname);
        ObjectOutputStream out = new ObjectOutputStream(fileOut);
        out.writeObject(this);
        out.close();
        fileOut.close();
        System.out.println("Game saved successfully.");
    } catch (IOException i) {
        System.out.println("Error saving game: " + i.getMessage());
    }

    }

   /** reads all information about the game from the specified file
    * * and returns a SpaceWars object
   * @param fname name of file storing the game
     * @return the game (as a SpaceWars object)
    */
   public SpaceWars restoreGame(String fname) {
       SpaceWars game = null;
       try {
           FileInputStream fileIn = new FileInputStream(fname);
           ObjectInputStream in = new ObjectInputStream(fileIn);
           game = (SpaceWars) in.readObject();
           in.close();
           fileIn.close();
       } catch (IOException i) {
           System.out.println("Error restoring game: " + i.getMessage());
       } catch (ClassNotFoundException c) {
           System.out.println("Error restoring game: " + c.getMessage());
       }
       return game;
   }

//
//     /** Reads information about battles from the specified file into the appropriate collection
//      * @param the name of the file
//      */

public void readBattles(String fname) {

    try (BufferedReader br = new BufferedReader(new FileReader(fname))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] tokens = line.split(",");
            String battleType = tokens[0];
            BattleType battleT=null;
            if(battleType.equals("Fight")) {
                battleT = BattleType.FIGHT;
            }
            else if(battleType.equals("Skirmish"))
            {
                battleT = BattleType.SKIRMISH;
            }
            else if(battleType.equals("Ambush"))
            {
                battleT =BattleType.AMBUSH;
            }
                String enemyName = tokens[1];
            int enemyStrngth = Integer.parseInt(tokens[2]);
            int looses = Integer.parseInt(tokens[3]);
            int gains = Integer.parseInt(tokens[4]);
            Battle battle=new Battle(battleT,enemyName,enemyStrngth,looses,gains);
            battleList.add(battle);







        }
    } catch (IOException e) {
        System.err.println("Error reading file: " + e.getMessage());
    }
}



}





