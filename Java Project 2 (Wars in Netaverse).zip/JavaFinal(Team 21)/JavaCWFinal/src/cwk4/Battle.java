package cwk4;

import java.io.Serializable;

public class Battle implements Serializable {
    private static int battleCounter = 1; // Counter to allocate unique numbers to battles
    private int number;
    private BattleType type;
    private String enemyName;
    private int enemyStrength;
    private int gains;
    private int losses;

    public Battle(BattleType type, String enemyName, int enemyStrength, int losses,int gains) {
        this.number = this.battleCounter++;
        if (battleCounter > 8) {
            battleCounter = 1;
        }
        this.type = type;
        this.enemyName = enemyName;
        //setEnemyStrength(enemyStrength);
        this.enemyStrength=enemyStrength;
        this.gains = gains;
        this.losses = losses;
    }

    public int getNumber() {
        return number;
    }

    public BattleType getType() {
        return type;
    }

    public String getEnemyName() {
        return enemyName;
    }

    public int getEnemyStrength() {
        return enemyStrength;
    }

    public int getGains() {
        return gains;
    }

    public int getLosses() {
        return losses;
    }

    public void setEnemyStrength(int enemyStrength) {

        this.enemyStrength = enemyStrength;
    }

    public String toString() {
        return "Battle Number:" + this.number +
                "\nBattle Type: " + this.type +
                "\nEnemy Name " + this.enemyName +
                "\n(Enemy Strength: " + enemyStrength +
                ", Gains: " + gains + ", Losses: " + losses + ")";
    }
}
