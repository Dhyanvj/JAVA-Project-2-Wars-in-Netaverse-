package cwk4;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

/**
 * Provide a GUI interface for the game
 *
 * @author A.A.Marczyk
 * @version 20/10/23
 */
public class GameGUI
{
    private WIN gp = new SpaceWars("Horatio");
    private JFrame myFrame = new JFrame("Game GUI");

    private JTextArea listing = new JTextArea();
    private JLabel codeLabel = new JLabel ();
    private JButton fightBtn = new JButton("Fight");
    private JPanel eastPanel = new JPanel();


    public GameGUI()
    {
        makeFrame();
        makeMenuBar(myFrame);
        myFrame.setSize(800, 1000);

    }

    /**
     * Create the main frame's menu bar.
     */
    private void makeMenuBar(JFrame frame)
    {
        JMenuBar menubar = new JMenuBar();
        frame.setJMenuBar(menubar);

        // create the Forces menu
        JMenu forcesMenu = new JMenu("Forces");
        menubar.add(forcesMenu);

        JMenuItem listForcesItem = new JMenuItem("List All Forces ");
        listForcesItem.addActionListener(new ListForcesHandler());
        forcesMenu.add(listForcesItem);

        JMenuItem listASFleetItem = new JMenuItem("List ASFleet");
        listASFleetItem.addActionListener(new ListASFleetHandler());
        forcesMenu.add(listASFleetItem);

        JMenuItem activateForce = new JMenuItem("Activate a Force");
        activateForce.addActionListener(new ActivateForceHandler());
        forcesMenu.add(activateForce);

        JMenuItem recallForce = new JMenuItem("Recall a Force");
        recallForce.addActionListener(new RecallForceHandler());
        forcesMenu.add(recallForce);




        JMenu menuItem = new JMenu("Battles");
        menubar.add(menuItem);

        JMenuItem battles = new JMenuItem("All Battles");
        battles.addActionListener(new ListBattlesHandler());
        menuItem.add(battles);




    }
    /**
     * Create the Swing frame and its content.
     */
    private void makeFrame()
    {
        myFrame.setLayout(new BorderLayout());
        myFrame.add(listing,BorderLayout.CENTER);
        listing.setVisible(false);
        myFrame.add(eastPanel, BorderLayout.EAST);
        // set panel layout and add components
        eastPanel.setLayout(new GridLayout(4,1));
        eastPanel.add(fightBtn);
        fightBtn.addActionListener(new FightBtnHandler());
        fightBtn.setVisible(true);


        JButton viewStateBtn = new JButton("View State");
        eastPanel.add(viewStateBtn);
        viewStateBtn.addActionListener(new ViewStateBtnHandler());
        viewStateBtn.setVisible(true);

        JButton clear = new JButton("Clear");
        eastPanel.add(clear);
        clear.addActionListener(new ClearBtnHandler());
        clear.setVisible(true);
        // building is done - arrange the components and show
        myFrame.pack();
        myFrame.setVisible(true);
    }


    private String fighting(int code)
    {
        switch (code)
        {
            case 0: return "Fight won";
            case 1:return "Fight lost as no suitable force available";
            case 2:return "Fight lost on battle strength, force destroyed";
            case 3:return "fight is lost and admiral completely defeated ";
        }
        return " no such fight ";
    }

    private class ListForcesHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            listing.setVisible(true);
            String xx = gp.getAllForces();
            listing.setText(xx);

        }
    }



    private class FightBtnHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            int result = -1;
            String inputValue = JOptionPane.showInputDialog("Fight number ?: ");
            int num = Integer.parseInt(inputValue);
            result = gp.doBattle(num);
            JOptionPane.showMessageDialog(myFrame,fighting(result));
        }
    }

    private class ListASFleetHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            listing.setVisible(true);
            String xx = gp.getASFleet().toString();
            listing.setText(xx);
        }
    }
    private class ActivateForceHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int result = 999;
            String forceId = JOptionPane.showInputDialog(myFrame, "Enter force Refference Number:");
            result=gp.activateForce(forceId);
            String message="Erorr";
            if(result==-1)
            {
                message="There is no such force with reference:"+forceId;
            }
            else if(result==0)
            {
                message="The force is  active";
            }
            else if(result==1){
                message="The force is being destroyed";
            }
            else if(result==2)
            {
                message="Not enough resources for activation fee";
            }
            else {
                message="The force is activated";
            }
            JOptionPane.showMessageDialog(myFrame, message);
        }
    }

    private class RecallForceHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String forceId = JOptionPane.showInputDialog(myFrame, "Enter force reference number:");

            gp.recallForce(forceId);
            JOptionPane.showMessageDialog(myFrame, "Recalled the Force");
        }
    }
    private class ListBattlesHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            listing.setVisible(true);
            String xx = gp.getAllBattles();
            listing.setText(xx);

        }
    }
    private class ViewStateBtnHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String state = gp.toString();
            listing.setVisible(true);
            listing.setText(state);
        }
    }
    private class ClearBtnHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            listing.setText(""); // set the text of JTextArea listing to empty string
        }
    }

    public static void main(String[] args)
    {
        new GameGUI();
    }
}

