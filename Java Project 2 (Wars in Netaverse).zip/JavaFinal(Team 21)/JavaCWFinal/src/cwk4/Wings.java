package cwk4;
public class Wings extends Force{
    //Declaring Variables
    private int strength;
    private int activationFee;
    private int strikers;
    //Constructor
    public Wings(String referenceNumber, String forceName,String forceState,int strikers) {
        super(referenceNumber, forceName,200,0, forceState);;
        this.strength = strikers * 20;
        super.setBattleStrength(this.strength);
        this.strikers = strikers;
    }
    @Override
    public String toString() {
        return super.toString()+

                "\nStrikers: " +this.strikers;
    }


}
