package cwk4;
public class StarShips extends Force{
    // Declaring Variables
    private int strength;
    private int activationFee;
    private int laserCannons;
    private int photonTorpedoes;

    // Constructor
    public StarShips(String referenceNumber, String forceName,String forceState,int laserCannons, int photonTorpedoes ){
        super(referenceNumber, forceName,0,0, forceState);

        this.activationFee = (laserCannons * 30);
        super.setActivationFee(this.activationFee);
        this.strength = (photonTorpedoes * 5) + (laserCannons * 10);
        super.setBattleStrength(this.strength);

        this.laserCannons = laserCannons;
        this.photonTorpedoes = photonTorpedoes;
    }
    @Override
    public String toString() {
        return super.toString()+
                "\nLaser Cannons: " + this.laserCannons+
                "\nPhoton Torpedoes: " + this.photonTorpedoes;
    }

}
