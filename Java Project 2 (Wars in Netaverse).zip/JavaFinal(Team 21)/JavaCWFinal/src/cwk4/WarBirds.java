package cwk4;

public class WarBirds extends Force {

    private boolean hasCloakingDevice;
    private int warStrength;

    public WarBirds(String referenceNumber, String forceName,int battleStrength,String forceState ,boolean hasCloakingDevice) {
        super(referenceNumber, forceName,0, battleStrength,forceState);
        this.hasCloakingDevice = hasCloakingDevice;
        this.warStrength = battleStrength;
        if (hasCloakingDevice) {
            super.setActivationFee(400);
        }
        else
        {
            super.setActivationFee(300);
        }

    }

    public boolean hasCloakingDevice() {
        return hasCloakingDevice;
    }

    public int getWarStrength() {
        return warStrength;
    }

    @Override
    public String toString() {
        return super.toString()+
                "\nHas Cloaking Device? " + hasCloakingDevice;
    }

}
