package cwk4; 


/**
 * Details of your team
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Teamwork
{
    private String[] details = new String[12];
    
    public Teamwork()
    {   // in each line replace the contents of the String 
        // with the details of your team member
        // Please list the member details alphabetically by surname 
        // i.e. the surname of member1 should come alphabetically 
        // before the surname of member 2...etc
        details[0] = "21";
        
        details[1] = "Patel";
        details[2] = "Dhyan Nilesh";
        details[3] = "21008521";

        details[4] = "Hussain";
        details[5] = "Md Numan";
        details[6] = "20072819";

        details[7] = "Sethi";
        details[8] = "Cheryl";
        details[9] = "20070709";


        details[10] = "Ud Din";
        details[11] = "Zain";
        details[12] = "20011960";

    }
    
    public String[] getTeamDetails()
    {
        return details;
    }
    
    public void displayDetails()
    {
        for(String temp:details)
        {
            System.out.println(temp.toString());
        }
    }
}
        
