package cwk4;

import java.io.Serializable;

public class Force implements Serializable {

    private String referenceNumber;
    private String forceName;
    private int activationFee;
    private int battleStrength;
    private ForceState forceState;

    public Force(String referenceNumber, String forceName, int activationFee, int battleStrength, String forceState) {
        this.referenceNumber = referenceNumber;
        this.forceName = forceName;
        this.activationFee = activationFee;
        this.battleStrength = battleStrength;
        this.forceState = ForceState.valueOf(forceState.toUpperCase());
    }
    public boolean hasCloakingDevice() {
        return false;
    }
    public void setForceState(String forceState) {
        this.forceState = ForceState.valueOf(forceState.toUpperCase());
    }

    public void setActivationFee(int fee) {
        this.activationFee=fee;
    }
    public void setBattleStrength(int strength) {
        this.battleStrength=strength;
    }
    public String getReferenceNumber() {
        return referenceNumber;
    }

    public String getForceName() {
        return forceName;
    }

    public int getActivationFee() {
        return activationFee;
    }

    public int getBattleStrength() {
        return battleStrength;
    }


    public ForceState getForceState() {
        return forceState;
    }

    public String toString() {

        return "Reference Number: " + referenceNumber +
                "\nForce Name: " + forceName +
                "\nActivation Fee: " + activationFee +
                "\nBattle Strength: " + battleStrength +
                "\nForce State: " + forceState;
    }


    public void setForceState(ForceState state) {
        this.forceState=state;

    }
}
